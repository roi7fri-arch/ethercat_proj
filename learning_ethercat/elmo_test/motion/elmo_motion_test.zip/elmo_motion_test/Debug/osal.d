osal.o: ../osal.c ../../../../SOEM-1.3.1/osal/osal.h \
 ../../../../SOEM-1.3.1/osal/linux/osal_defs.h

../../../../SOEM-1.3.1/osal/osal.h:

../../../../SOEM-1.3.1/osal/linux/osal_defs.h:
