elmo_com.o: ../elmo_com.c ../../../../SOEM-1.3.1/soem/ethercattype.h \
 ../../../../SOEM-1.3.1/osal/osal.h \
 ../../../../SOEM-1.3.1/osal/linux/osal_defs.h \
 ../../../../SOEM-1.3.1/oshw/linux/nicdrv.h \
 ../../../../SOEM-1.3.1/soem/ethercatbase.h \
 ../../../../SOEM-1.3.1/soem/ethercatmain.h \
 ../../../../SOEM-1.3.1/soem/ethercatconfig.h \
 ../../../../SOEM-1.3.1/soem/ethercatcoe.h \
 ../../../../SOEM-1.3.1/soem/ethercatdc.h \
 ../../../../SOEM-1.3.1/soem/ethercatprint.h ../slave_mapping_info.h \
 ../elmo_ICD.h ../elmo_device.h ../params.h ../joystick_eth.h

../../../../SOEM-1.3.1/soem/ethercattype.h:

../../../../SOEM-1.3.1/osal/osal.h:

../../../../SOEM-1.3.1/osal/linux/osal_defs.h:

../../../../SOEM-1.3.1/oshw/linux/nicdrv.h:

../../../../SOEM-1.3.1/soem/ethercatbase.h:

../../../../SOEM-1.3.1/soem/ethercatmain.h:

../../../../SOEM-1.3.1/soem/ethercatconfig.h:

../../../../SOEM-1.3.1/soem/ethercatcoe.h:

../../../../SOEM-1.3.1/soem/ethercatdc.h:

../../../../SOEM-1.3.1/soem/ethercatprint.h:

../slave_mapping_info.h:

../elmo_ICD.h:

../elmo_device.h:

../params.h:

../joystick_eth.h:
