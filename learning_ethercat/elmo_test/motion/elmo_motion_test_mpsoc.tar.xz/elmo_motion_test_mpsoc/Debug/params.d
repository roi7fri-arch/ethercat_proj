params.d: ../params.c ../params.h

../params.h:
