joysitck.d: ../joysitck.c ../joystick_eth.h

../joystick_eth.h:
